package com.example.autofish

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(Color.rgb(24, 27, 36))
        }
        val title = TextView(this).apply {
            text = "AUTO FISH"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "1. 다른 앱 위에 표시 권한 허용\n2. 접근성에서 AUTO FISH 서비스 켜기\n3. 로블록스를 실행한 뒤 플로팅 창 사용\n\n화면 색상 감지 방식의 초기 프로토타입입니다. 게임 업데이트나 화면 배율에 따라 감지 위치 조정이 필요할 수 있습니다."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, 24, 0, 24)
        }
        val overlay = Button(this).apply {
            text = "다른 앱 위에 표시 권한 설정"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        val accessibility = Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val launch = Button(this).apply {
            text = "플로팅 창 열기"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                } else {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                }
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(overlay)
        layout.addView(accessibility)
        layout.addView(launch)
        setContentView(layout)
    }
}
