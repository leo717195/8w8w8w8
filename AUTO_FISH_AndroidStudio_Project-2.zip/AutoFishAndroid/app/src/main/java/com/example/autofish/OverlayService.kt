package com.example.autofish

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.content.Context

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var status: TextView
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
        if (panel == null) showPanel()
        return START_STICKY
    }

    private fun showPanel() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 10, 12, 10)
            background = GradientDrawable().apply {
                setColor(Color.rgb(28, 31, 42)); cornerRadius = 22f
                setStroke(2, Color.rgb(110, 120, 145))
            }
        }
        val header = TextView(this).apply {
            text = "AUTO FISH  ⋮"
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(8, 8, 8, 12)
        }
        status = TextView(this).apply {
            text = "상태: 대기 중"; textSize = 12f
            setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(4, 4, 4, 10)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val start = Button(this).apply {
            text = "시작"; setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(22, 132, 69))
            setOnClickListener {
                FishAccessibilityService.instance?.startFishing()
                status.text = "상태: 실행 중"
            }
        }
        val stop = Button(this).apply {
            text = "정지"; setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(190, 55, 55))
            setOnClickListener {
                FishAccessibilityService.instance?.stopFishing()
                status.text = "상태: 정지"
            }
        }
        row.addView(start, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(stop, LinearLayout.LayoutParams(0, -2, 1f))
        val resize = TextView(this).apply {
            text = "◢ 크기 조절"; setTextColor(Color.LTGRAY)
            gravity = Gravity.RIGHT; setPadding(8, 8, 8, 4)
        }
        root.addView(header); root.addView(status); root.addView(row); root.addView(resize)
        params = WindowManager.LayoutParams(
            270, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 18; y = 160 }
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=params.x; sy=params.y; tx=e.rawX; ty=e.rawY; return true }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = sx - (e.rawX-tx).toInt()
                        params.y = sy + (e.rawY-ty).toInt()
                        wm.updateViewLayout(root, params); return true
                    }
                }
                return true
            }
        })
        resize.setOnTouchListener(object : View.OnTouchListener {
            var startX=0f; var startW=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) { startX=e.rawX; startW=params.width; return true }
                if (e.action == MotionEvent.ACTION_MOVE) {
                    params.width = (startW + (startX-e.rawX).toInt()).coerceIn(220, 520)
                    wm.updateViewLayout(root, params); return true
                }
                return true
            }
        })
        panel = root
        wm.addView(root, params)
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }; panel = null
        FishAccessibilityService.instance?.stopFishing()
        super.onDestroy()
    }
}
