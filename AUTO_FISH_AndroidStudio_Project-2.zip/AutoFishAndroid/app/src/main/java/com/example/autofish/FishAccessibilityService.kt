package com.example.autofish

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.GestureDescription
import android.graphics.Path
import java.util.concurrent.Executors

class FishAccessibilityService : AccessibilityService() {
    companion object { var instance: FishAccessibilityService? = null }
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var running = false
    private var tappingUntil = 0L

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopFishing() }
    override fun onDestroy() { stopFishing(); instance = null; super.onDestroy() }

    fun startFishing() {
        if (Build.VERSION.SDK_INT < 30) return
        running = true
        handler.removeCallbacks(loop)
        handler.post(loop)
    }
    fun stopFishing() {
        running = false
        handler.removeCallbacks(loop)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            if (Build.VERSION.SDK_INT >= 30) {
                takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                    object : TakeScreenshotCallback {
                        override fun onSuccess(result: ScreenshotResult) {
                            val buffer = result.hardwareBuffer
                            val bitmap = Bitmap.wrapHardwareBuffer(buffer, result.colorSpace)
                            buffer.close()
                            if (bitmap != null) {
                                val decision = detect(bitmap)
                                bitmap.recycle()
                                when (decision.first) {
                                    "CHARGE" -> tap(decision.second.first, decision.second.second)
                                    "BITE" -> {
                                        tappingUntil = System.currentTimeMillis() + 1800
                                        rapidTap()
                                    }
                                }
                            }
                            if (running) handler.postDelayed(loop, 250)
                        }
                        override fun onFailure(errorCode: Int) {
                            if (running) handler.postDelayed(loop, 600)
                        }
                    })
            }
        }
    }

    // Initial color heuristic based on the supplied screenshots; tune thresholds for the device/game UI.
    private fun detect(b: Bitmap): Pair<String, Pair<Float,Float>> {
        val w=b.width; val h=b.height
        var yellowX=0L; var yellowY=0L; var yellowN=0
        val x0=(w*0.48).toInt(); val x1=(w*0.66).toInt()
        val y0=(h*0.18).toInt(); val y1=(h*0.66).toInt()
        var y=y0
        while (y<y1) {
            var x=x0
            while (x<x1) {
                val c=b.getPixel(x,y)
                val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
                if (r>190 && g>155 && bl<105 && r>g*0.92) {
                    yellowX+=x; yellowY+=y; yellowN++
                }
                x+=3
            }
            y+=3
        }
        if (yellowN>16) return Pair("CHARGE", Pair((yellowX.toFloat()/yellowN)/w, (yellowY.toFloat()/yellowN)/h))

        // Bite minigame: bright lime pixels in the lower-middle progress-bar band.
        var greenX=0L; var greenY=0L; var greenN=0
        val bx0=(w*0.22).toInt(); val bx1=(w*0.76).toInt()
        val by0=(h*0.78).toInt(); val by1=(h*0.96).toInt()
        y=by0
        while (y<by1) {
            var x=bx0
            while (x<bx1) {
                val c=b.getPixel(x,y)
                val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
                if (g>170 && r<150 && bl<170) { greenX+=x; greenY+=y; greenN++ }
                x+=3
            }
            y+=3
        }
        if (greenN>24) return Pair("BITE", Pair((greenX.toFloat()/greenN)/w, (greenY.toFloat()/greenN)/h))
        return Pair("WAIT", Pair(0.5f,0.5f))
    }

    private fun rapidTap() {
        if (!running || System.currentTimeMillis()>tappingUntil) return
        // Repeated taps at the detected green target's approximate lower-screen location.
        tap(0.50f, 0.89f)
        handler.postDelayed({ rapidTap() }, 90)
    }

    private fun tap(nx: Float, ny: Float) {
        val dm=resources.displayMetrics
        val x=(nx*dm.widthPixels).coerceIn(1f, dm.widthPixels-1f)
        val y=(ny*dm.heightPixels).coerceIn(1f, dm.heightPixels-1f)
        val path=Path().apply { moveTo(x,y) }
        val gesture=GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path,0,45))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
